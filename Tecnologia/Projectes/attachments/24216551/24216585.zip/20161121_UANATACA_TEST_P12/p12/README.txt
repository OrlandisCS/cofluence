PIN: 12345



           ARCHIVO           |            PERFIL
--------------------------------------------------------------------------------
ep_alto_aut.p12              |  Empleado P�blico nivel alto AUTENTICACI�N
ep_alto_cifrado.p12          |  Empleado P�blico nivel alto CIFRADO
ep_alto_firma.p12            |  Empleado P�blico nivel alto FIRMA
ep_medio.p12                 |  Empleado P�blico nivel MEDIO
pf_dscf_aut.p12              |  Persona F�sica en DSCF AUTENTICACI�N
pf_dscf_cifrado.p12          |  Persona F�sica en DSCF CIFRADO
pf_dscf_firma.p12            |  Persona F�sica en DSCF FIRMA
pf_soft.p12                  |  Persona F�sica en software
r_dscf_aut.p12               |  Representante legal en DSCF AUTENTICACI�N
r_dscf_cifrado.p12           |  Representante legal en DSCF CIFRADO
r_dscf_firma.p12             |  Representante legal en DSCF FIRMA
r_soft.p12                   |  Representante en software
afirma_rl_aut_dscf.p12       |  Representante aFirma en DSCF AUTENTICACI�N
afirma_rl_cifrado_dscf.p12   |  Representante aFirma en DSCF CIFRADO
afirma_rl_firma_dscf.p12     |  Representante aFirma en DSCF FIRMA
afirma_rl_soft.p12           |  Representante aFirma en software
so_alto.p12                  |  Sello de �rgano NIVEL ALTO
so_medio.p12                 |  Sello de �rgano NIVEL MEDIO
